const express = require("express");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("public"));

let text = "";

io.on("connection", (socket) => {
  socket.emit("load", text);

  socket.on("typing", (data) => {
    text = data;
    socket.broadcast.emit("update", data);
  });
});

server.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
